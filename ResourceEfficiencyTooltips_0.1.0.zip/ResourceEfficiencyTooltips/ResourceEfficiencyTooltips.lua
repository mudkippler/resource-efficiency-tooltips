-- Resource Efficiency Tooltips
-- Appends damage / healing / absorb per point of mana to the mana cost line of spell tooltips.
-- Amounts are read from the tooltip's own description text, so they match the rank being shown.

local _, ns = ...

local format = string.format
local issecret = issecretvalue or function() return false end

-- The description parser only understands English tooltip text.
local SUPPORTED_LOCALES = { enUS = true, enGB = true }

-- Only annotate tooltips players look at; other addons' hidden scanning tooltips must not
-- be modified (or shown).
local TOOLTIPS = { GameTooltip = true, ItemRefTooltip = true }

local TAG = "/mana" -- also used to detect tooltips we've already annotated
local MANA_POWER = (Enum and Enum.PowerType and Enum.PowerType.Mana) or 0

local ORDER = { "damage", "heal", "absorb" }
local LABELS = { damage = "dmg", heal = "heal", absorb = "absorb" }
local COLORS = { damage = "ffff9040", heal = "ff40ff60", absorb = "ff80c8ff" }

-- A number followed by one of these words isn't a damage/healing amount ("10 yards", "40%", "5 sec").
local UNIT_WORDS = {
    "yd", "yard", "sec", "second", "min", "hour", "ms", "target", "enem", "member",
    "time", "charge", "stack", "combo", "level", "health", "mana", "rage", "energy", "feet", "foot",
    "party", "raid", "group", "ally", "allies",
}

-- A sentence containing any of these hits multiple targets, so its ratio is per target.
local AOE_PATTERNS = {
    "enemies", "targets", "party members", "group members", "raid members", "allies",
    "target area", "area of effect", "in an area", "in a cone", "nearby",
}

-- Seconds between attacks for summons whose tooltip says "repeatedly attacks" without
-- giving an interval. Keyed by lowercase spell name.
local SHOT_INTERVALS = {
    ["searing totem"] = 2.4,
}

---------------------------------------------------------------------------
-- Text helpers
---------------------------------------------------------------------------

local function EscapePattern(s)
    return (s:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"))
end

local function ToNum(s)
    return tonumber((s:gsub("[,%.]$", "")))
end

local function Normalize(text)
    text = text:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", "")
    text = text:gsub("|T.-|t", ""):gsub("|H.-|h(.-)|h", "%1")
    -- Thousands separators: "1,234,567" -> "1234567"
    text = text:gsub("(%d),(%d%d%d)", "%1%2"):gsub("(%d),(%d%d%d)", "%1%2")
    return text:lower()
end

---------------------------------------------------------------------------
-- Mana cost
---------------------------------------------------------------------------

local MANA_WORD = (type(MANA) == "string" and MANA or "Mana"):lower()
local COST_PATTERNS = {}
if type(MANA_COST) == "string" then
    -- e.g. "%d Mana" -> "^([%d,%.]+) mana"
    local p = EscapePattern(MANA_COST:lower()):gsub("%%d", "([%%d,%%.]+)"):gsub("%%s", ".-")
    COST_PATTERNS[#COST_PATTERNS + 1] = "^" .. p
end
COST_PATTERNS[#COST_PATTERNS + 1] = "^([%d,%.]+)%s*" .. EscapePattern(MANA_WORD)
local PERCENT_COST_PATTERN = "^[%d%.]+%%.-" .. EscapePattern(MANA_WORD)

-- Returns isManaLine, cost (cost is nil for percentage costs such as "12% of base mana").
local function MatchManaCost(text)
    local lower = text:lower()
    for _, pattern in ipairs(COST_PATTERNS) do
        local num = lower:match(pattern)
        if num then
            return true, tonumber((num:gsub(",", "")))
        end
    end
    if lower:find(PERCENT_COST_PATTERN) then
        return true, nil
    end
    return false
end

local GetPowerCost = (C_Spell and C_Spell.GetSpellPowerCost) or GetSpellPowerCost

local function GetManaCostFromAPI(spellID)
    if not (GetPowerCost and spellID) then return nil end
    local ok, cost = pcall(function()
        for _, entry in ipairs(GetPowerCost(spellID) or {}) do
            if (entry.type == MANA_POWER or entry.name == "MANA") and entry.cost and entry.cost > 0 then
                return entry.cost
            end
        end
    end)
    return ok and cost or nil
end

---------------------------------------------------------------------------
-- Description parsing
---------------------------------------------------------------------------

local function IsUnitWord(word)
    if word:sub(1, 1) == "%" then return true end
    for _, unit in ipairs(UNIT_WORDS) do
        if word:sub(1, #unit) == unit then return true end
    end
    return false
end

-- Finds the first amount in a clause ("31 to 45" averages to 38).
-- Returns the amount and the text that follows it.
local function FindAmount(clause)
    local pos = 1
    while true do
        local s, e, num = clause:find("(%d+%.?%d*)", pos)
        if not s then return nil end
        local value, rest = ToNum(num), clause:sub(e + 1)
        local _, e2, num2 = rest:find("^%s+to%s+(%d+%.?%d*)")
        if e2 then
            value = (value + ToNum(num2)) / 2
            rest = rest:sub(e2 + 1)
        end
        local word = rest:match("^%s*(%S*)")
        local before = clause:sub(1, s - 1)
        -- "by N" / "by up to N" modifies other damage or healing (Dampen Magic's "healing by up to 20").
        local isModifier = before:find("%f[%a]by%s*$") or before:find("%f[%a]by%s+up%s+to%s*$")
        if value and not isModifier and not IsUnitWord(word) and not before:find("level%s*$")
            and not before:find("rank%s*$") then
            return value, rest
        end
        pos = e + (e2 or 0) + 1
    end
end

local function ParseDuration(text, prefix)
    local sec = text:match(prefix .. "%s+(%d+%.?%d*)%s*sec")
    if sec then return ToNum(sec) end
    local min = text:match(prefix .. "%s+(%d+%.?%d*)%s*min")
    if min then return ToNum(min) * 60 end
    return nil
end

-- Turns a per-tick amount into a total: "26 damage each second for 3 sec" -> x3.
-- Summons that "repeatedly attack" use shotInterval (seconds) over their duration.
-- Returns multiplier, isPerTick (true when ticks were found but no duration).
local function TickMultiplier(clause, rest, lasts, shotInterval)
    if rest:find("over%s+%d") then return 1, false end -- already a total
    local interval = rest:match("every%s+(%d+%.?%d*)%s*sec")
    interval = interval and ToNum(interval)
    if not interval and (rest:find("every%s+sec") or rest:find("each%s+sec") or rest:find("per%s+sec")) then
        interval = 1
    end
    if not interval and clause:find("repeatedly") then
        if not shotInterval then return 1, true end
        interval = shotInterval
    end
    if not interval or interval <= 0 then return 1, false end
    local duration = ParseDuration(rest, "for") or ParseDuration(clause, "for") or lasts
    if not duration then return 1, true end
    return math.max(1, math.floor(duration / interval + 0.5)), false
end

-- false = clause doesn't describe throughput (and stops inheriting), nil = inherit the previous kind.
local function ClauseKind(clause)
    if clause:find("yourself") or clause:find("himself") or clause:find("herself") or clause:find("itself") then
        return false
    end
    if clause:find("increas") or clause:find("reduc") or clause:find("decreas") then
        return false
    end
    -- Per-point conversions (Mana Burn's "for each mana destroyed ... takes 0.5 damage").
    if clause:find("each mana") or clause:find("per mana") then
        return false
    end
    if clause:find("absorb") then return "absorb" end
    -- "health" (e.g. a totem "with 5 health") isn't healing.
    if clause:gsub("health", ""):find("heal") then return "heal" end
    if clause:find("damage") then return "damage" end
    return nil
end

local WORD_NUMBERS = {
    two = 2, three = 3, four = 4, five = 5, six = 6, seven = 7, eight = 8, nine = 9, ten = 10,
}

-- Number of times a charge-based effect can trigger per cast, e.g. Lightning Shield's
-- "3 charges", "three charges", "can be hit by an attacker 3 times", or
-- "surrounded by 3 balls of lightning ... this expends one lightning ball".
local function ParseCharges(text)
    local suffixes = { "charges?", "times" }
    local expended = text:match("expends one ([%a%s]-)[%.,;]") or text:match("consumes one ([%a%s]-)[%.,;]")
    local noun = expended and expended:match("(%a+)%s*$")
    if noun then
        table.insert(suffixes, 1, noun:gsub("s$", "") .. "s?")
    end
    for _, suffix in ipairs(suffixes) do
        for count in text:gmatch("(%w+)%s+" .. suffix) do
            local charges = tonumber(count) or WORD_NUMBERS[count]
            if charges and charges > 1 then return charges end
        end
    end
    return 1
end

local function IsAoE(sentence)
    for _, pattern in ipairs(AOE_PATTERNS) do
        if sentence:find(pattern, 1, true) then return true end
    end
    return false
end

-- Mana drained per point of damage absorbed, e.g. Mana Shield's "draining 2 mana per damage absorbed".
local function ParseAbsorbDrain(text)
    if not text:find("absorb") then return nil end
    local mana, damage = text:match("(%d+%.?%d*) mana per (%d+%.?%d*) [%a%s]-damage")
    if mana then return ToNum(mana) / ToNum(damage) end
    mana = text:match("(%d+%.?%d*) mana per") or text:match("(%d+%.?%d*) mana for each")
        or text:match("drain%a* (%d+%.?%d*) mana") or text:match("cost%a* (%d+%.?%d*) mana")
    return mana and ToNum(mana)
end

-- lines: normalized (lowercase) tooltip lines; spellName: lowercase spell name, if known.
-- Returns totals[kind], perTick[kind], aoe[kind], absorbDrain (mana per point absorbed, or nil).
local function Analyze(lines, spellName)
    local totals, perTick, aoe = {}, {}, {}
    local fullText = table.concat(lines, " ")
    -- Weapon imbues (Flametongue, Frostbrand, Windfury...) and Paladin seals scale with
    -- weapon hits, not casts.
    if fullText:find("imbue") or fullText:find("only one seal") or fullText:find("each melee attack") then
        return totals, perTick, aoe, nil
    end
    local lasts = ParseDuration(fullText, "lasts")
    local charges = ParseCharges(fullText)
    local shotInterval = spellName and SHOT_INTERVALS[spellName]
    for _, line in ipairs(lines) do
        local sentences = line:gsub("%.%s+", "\1")
        for sentence in sentences:gmatch("[^\1]+") do
            local kind
            local sentenceIsAoE = IsAoE(sentence)
            local clauses = sentence:gsub("%s+and%s+", "\2"):gsub(";", "\2")
            for clause in clauses:gmatch("[^\2]+") do
                local clauseKind = ClauseKind(clause)
                if clauseKind == false then
                    kind = nil
                elseif clauseKind then
                    kind = clauseKind
                end
                if clauseKind ~= false and kind then
                    local value, rest = FindAmount(clause)
                    if value and value > 0 then
                        local mult, tick = TickMultiplier(clause, rest, lasts, shotInterval)
                        totals[kind] = (totals[kind] or 0) + value * mult * charges
                        perTick[kind] = perTick[kind] or tick
                        aoe[kind] = aoe[kind] or sentenceIsAoE
                    end
                end
            end
        end
    end
    return totals, perTick, aoe, ParseAbsorbDrain(fullText)
end

---------------------------------------------------------------------------
-- Tooltip
---------------------------------------------------------------------------

local function FormatRatio(ratio)
    if ratio >= 10 then return format("%.1f", ratio) end
    return format("%.2f", ratio)
end

-- Action button tooltips refresh several times a second; cache the suffix per tooltip text.
local cache = {}
local cacheKeys = {}
local CACHE_SIZE = 200

local function BuildSuffix(lines, cost, spellName)
    local totals, perTick, aoe, absorbDrain = Analyze(lines, spellName)
    local parts = {}
    for _, kind in ipairs(ORDER) do
        local total = totals[kind]
        if total and total > 0 then
            -- Shields that drain mana as they absorb (Mana Shield) cost the cast plus the drain.
            local totalCost = cost
            if kind == "absorb" and absorbDrain then
                totalCost = cost + total * absorbDrain
            end
            parts[#parts + 1] = format("|c%s%s %s%s%s%s|r", COLORS[kind], FormatRatio(total / totalCost),
                LABELS[kind], TAG, perTick[kind] and " per tick" or "", aoe[kind] and " per target" or "")
        end
    end
    if #parts == 0 then return false end
    return "  (" .. table.concat(parts, ", ") .. ")"
end

local function GetSuffix(lines, cost, spellName)
    local key = cost .. "|" .. (spellName or "") .. "|" .. table.concat(lines, "|")
    local suffix = cacheKeys[key]
    if suffix == nil then
        suffix = BuildSuffix(lines, cost, spellName)
        if #cache >= CACHE_SIZE then
            cacheKeys[table.remove(cache, 1)] = nil
        end
        cache[#cache + 1] = key
        cacheKeys[key] = suffix
    end
    return suffix
end

local function Process(tooltip, spellID)
    if not tooltip or (tooltip.IsForbidden and tooltip:IsForbidden()) then return end
    local name = tooltip:GetName()
    if not name or not TOOLTIPS[name] then return end

    local manaLine, cost
    local lines = {}
    for i = 2, tooltip:NumLines() do
        local fontString = _G[name .. "TextLeft" .. i]
        local text = fontString and fontString:GetText()
        if text and not issecret(text) then
            if text:find(TAG, 1, true) then return end -- already annotated
            local lower = Normalize(text)
            if lower:find("^next rank") then break end
            local isMana, lineCost = false, nil
            if not manaLine and i <= 5 then
                isMana, lineCost = MatchManaCost(lower)
            end
            if isMana then
                manaLine, cost = fontString, lineCost
            else
                lines[#lines + 1] = lower
            end
        end
    end
    if not manaLine then return end

    cost = cost or GetManaCostFromAPI(spellID)
    if not cost or cost <= 0 then return end

    local titleLine = _G[name .. "TextLeft1"]
    local spellName = titleLine and titleLine:GetText()
    if spellName and issecret(spellName) then spellName = nil end
    ns.lastSpell = { name = spellName, id = spellID, lines = lines }
    local suffix = GetSuffix(lines, cost, spellName and Normalize(spellName))
    if not suffix then return end

    manaLine:SetText(manaLine:GetText() .. suffix)
    if tooltip:IsShown() then
        tooltip:Show() -- resize to fit the longer line
    end
end

if not SUPPORTED_LOCALES[GetLocale()] then
    -- Leave tooltips alone rather than show wrong numbers.
elseif TooltipDataProcessor and TooltipDataProcessor.AddTooltipPostCall and Enum and Enum.TooltipDataType then
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Spell, function(tooltip, data)
        Process(tooltip, data and data.id)
    end)
else
    GameTooltip:HookScript("OnTooltipSetSpell", function(self)
        local _, spellID = self:GetSpell()
        Process(self, spellID)
    end)
end

ns.Analyze = Analyze

-- /ret: prints the text of the last annotated spell tooltip, for debugging the parser.
SLASH_RESOURCEEFFICIENCYTOOLTIPS1 = "/ret"
SlashCmdList.RESOURCEEFFICIENCYTOOLTIPS = function()
    local last = ns.lastSpell
    if not last then
        print("|cff80c8ffResource Efficiency Tooltips:|r hover a spell with a mana cost first.")
        return
    end
    print(format("|cff80c8ffResource Efficiency Tooltips:|r %s (%s)", tostring(last.name), tostring(last.id)))
    for i, line in ipairs(last.lines) do
        print(format("  %d: %s", i, line))
    end
end
